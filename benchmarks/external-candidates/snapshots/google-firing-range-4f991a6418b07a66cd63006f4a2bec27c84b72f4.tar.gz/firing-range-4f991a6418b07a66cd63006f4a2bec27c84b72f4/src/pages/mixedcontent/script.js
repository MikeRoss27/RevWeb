var f = function() {};
