use super::*;
use webrev_core::SessionId;

fn inputs(sources: &[(&str, &str)]) -> Vec<ExtractInput> {
    let session = SessionId::new();
    sources
        .iter()
        .map(|(path, body)| {
            ExtractInput::new(
                session,
                Some(format!("https://example.test/{path}")),
                ContentKind::JavaScript,
                *body,
            )
        })
        .collect()
}
fn flows(sources: &[(&str, &str)]) -> Vec<Finding> {
    DomSinkExtractor::extract_modules(&inputs(sources))
}
#[test]
fn named_alias_and_default_imports_preserve_provenance() {
    for source in [
        "const value = location.hash; export {value as payload};",
        "export const payload = location.hash;",
    ] {
        let found = flows(&[
            ("source.js", source),
            (
                "sink.js",
                "import {payload as data} from './source.js'; document.write(data);",
            ),
        ]);
        assert_eq!(found.len(), 1);
        assert_eq!(found[0].value, "DOM XSS: location.hash -> document.write");
        assert_eq!(found[0].status, webrev_core::FindingStatus::Suspicious);
        assert_eq!(found[0].confidence, Confidence::Medium);
        assert_eq!(found[0].provenances.len(), 2);
    }
    assert_eq!(
        flows(&[
            ("source.js", "export default location.hash;"),
            ("sink.js", "import data from './source.js'; eval(data);")
        ])
        .len(),
        1
    );
}
#[test]
fn relative_urls_and_chains_work_without_order_dependence() {
    let found = flows(&[
        (
            "app/sink.js",
            "import {value} from '../bridge.js'; eval(value);",
        ),
        (
            "bridge.js",
            "import {payload} from './source.js'; export const value = payload;",
        ),
        ("source.js", "export const payload = location.search;"),
    ]);
    assert_eq!(found.len(), 1);
    assert_eq!(found[0].provenances.len(), 3);
}
#[test]
fn missing_wrong_bare_and_unexported_imports_never_link() {
    for import in [
        "import {missing as payload} from './source.js';",
        "import {payload} from './other.js';",
        "import {payload} from 'source.js';",
        "const payload = 'safe';",
    ] {
        assert!(flows(&[
            ("source.js", "export const payload = location.hash;"),
            ("sink.js", &format!("{import} eval(payload);"))
        ])
        .is_empty());
    }
    assert!(flows(&[
        ("source.js", "const payload = location.hash;"),
        (
            "sink.js",
            "import {payload} from './source.js'; eval(payload);"
        )
    ])
    .is_empty());
}
#[test]
fn sanitizers_overwrites_numeric_results_and_shadowing_stop_flow() {
    for body in [
        "eval(DOMPurify.sanitize(payload));",
        "let data = payload; data = 'safe'; eval(data);",
        "eval(payload.search('x'));",
        "function f(payload) {eval(payload);}",
        "const f = payload => eval(payload);",
        "function f({payload}) {eval(payload);}",
        "function f([payload]) {eval(payload);}",
        "function f() { const {payload} = safe; eval(payload); }",
        "try {doSomething();} catch(payload) {eval(payload);}",
    ] {
        assert!(
            flows(&[
                ("source.js", "export const payload = location.hash;"),
                (
                    "sink.js",
                    &format!("import {{payload}} from './source.js'; {body}")
                )
            ])
            .is_empty(),
            "{body}"
        );
    }
    assert!(flows(&[
        (
            "source.js",
            "let payload = location.hash; payload = 'safe'; export {payload};"
        ),
        (
            "sink.js",
            "import {payload} from './source.js'; eval(payload);"
        )
    ])
    .is_empty());
}
#[test]
fn sessions_cycles_parse_errors_and_caps_do_not_invent_sources() {
    let mut separate = inputs(&[
        ("source.js", "export const payload = location.hash;"),
        (
            "sink.js",
            "import {payload} from './source.js'; eval(payload);",
        ),
    ]);
    separate[1].session_id = SessionId::new();
    assert!(DomSinkExtractor::extract_modules(&separate).is_empty());
    assert!(flows(&[
        (
            "source.js",
            "import {value} from './sink.js'; export const payload=value;"
        ),
        (
            "sink.js",
            "import {payload} from './source.js'; export const value=payload; eval(value);"
        )
    ])
    .is_empty());
    assert!(flows(&[
        ("source.js", "export const payload = location.hash; ???"),
        (
            "sink.js",
            "import {payload} from './source.js'; eval(payload);"
        )
    ])
    .is_empty());
    let oversized = format!(
        "export const payload = location.hash; /*{}*/",
        "x".repeat(MAX_MODULE_BYTES)
    );
    assert!(flows(&[
        ("source.js", &oversized),
        (
            "sink.js",
            "import {payload} from './source.js'; eval(payload);"
        )
    ])
    .is_empty());
}

#[test]
fn conflicting_urls_are_excluded_in_both_orders() {
    let mut conflicting = inputs(&[
        ("source.js", "export const payload = location.hash;"),
        ("source.js", "export const payload = 'safe';"),
        (
            "sink.js",
            "import {payload} from './source.js'; eval(payload);",
        ),
    ]);
    assert!(DomSinkExtractor::extract_modules(&conflicting).is_empty());
    conflicting.reverse();
    assert!(DomSinkExtractor::extract_modules(&conflicting).is_empty());
}

#[test]
fn default_exports_are_snapshots_and_block_bindings_do_not_escape() {
    for source in [
        "let payload='safe'; export default payload; payload=location.hash;",
        "const payload='safe'; { const payload=location.hash; } export {payload as default};",
        "let payload=location.hash; {payload='safe';} export {payload as default};",
    ] {
        assert!(
            flows(&[
                ("source.js", source),
                (
                    "sink.js",
                    "import payload from './source.js'; eval(payload);"
                )
            ])
            .is_empty(),
            "{source}"
        );
    }
    assert_eq!(
        flows(&[
            (
                "source.js",
                "let payload=location.hash; export default payload; payload='safe';"
            ),
            (
                "sink.js",
                "import payload from './source.js'; eval(payload);"
            )
        ])
        .len(),
        1
    );
}
