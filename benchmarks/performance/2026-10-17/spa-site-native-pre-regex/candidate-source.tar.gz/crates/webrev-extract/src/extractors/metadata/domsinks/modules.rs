//! Bounded ES-module linking. Only explicit named/default value exports cross
//! file boundaries; unresolved imports, namespace imports, functions, dynamic
//! imports and cycles without a concrete source never invent a flow.
use super::{
    pat_ident_name, BTreeMap, BTreeSet, BytePos, Confidence, ContentKind, DomSinkExtractor,
    EsSyntax, Expr, ExtractInput, FileName, Finding, FindingKind, Lrc, Parser, Provenance, Source,
    SourceMap, StringInput, Syntax, TaintVisitor, VisitWith,
};
use swc_core::ecma::ast::{
    Decl, ExportSpecifier, ImportSpecifier, Module, ModuleDecl, ModuleExportName, ModuleItem, Stmt,
};
use url::Url;

/// Limits also apply to the pipeline's retained JavaScript inputs.
pub const MAX_MODULES: usize = 128;
pub const MAX_MODULE_BYTES: usize = 512 * 1024;
pub const MAX_TOTAL_BYTES: usize = 8 * 1024 * 1024;
const MAX_LINK_PASSES: usize = 8;

#[derive(Clone, PartialEq, Eq)]
struct ExportValue {
    origin: String,
    locations: BTreeSet<String>,
}

struct ParsedModule {
    url: Url,
    module: Module,
}

type Exports = BTreeMap<(String, String), ExportValue>;

fn export_name(name: &ModuleExportName) -> String {
    match name {
        ModuleExportName::Ident(id) => id.sym.to_string(),
        ModuleExportName::Str(value) => value.value.to_string_lossy().into_owned(),
    }
}

fn parse(input: &ExtractInput) -> Option<ParsedModule> {
    if input.kind != ContentKind::JavaScript || input.body.len() > MAX_MODULE_BYTES {
        return None;
    }
    let url = Url::parse(input.url.as_deref()?).ok()?;
    let cm: Lrc<SourceMap> = Lrc::default();
    let fm = cm.new_source_file(Lrc::new(FileName::Anon), input.body.clone());
    let len = u32::try_from(fm.src.len()).ok()?;
    let mut parser = Parser::new(
        Syntax::Es(EsSyntax {
            jsx: true,
            ..EsSyntax::default()
        }),
        StringInput::new(&fm.src, BytePos(0), BytePos(len)),
        None,
    );
    let module = parser.parse_module().ok()?;
    if !parser.take_errors().is_empty() {
        return None;
    }
    Some(ParsedModule { url, module })
}

/// URL resolution follows explicit browser module specifiers; bare package
/// specifiers require an import map, which this analysis does not model.
fn resolve(base: &Url, specifier: &str) -> Option<String> {
    if !(specifier.starts_with("./")
        || specifier.starts_with("../")
        || specifier.starts_with('/')
        || Url::parse(specifier).is_ok())
    {
        return None;
    }
    base.join(specifier).ok().map(|url| url.to_string())
}

fn seed_imports(
    parsed: &ParsedModule,
    exports: &Exports,
) -> (TaintVisitor, BTreeMap<String, ExportValue>) {
    let mut visitor = TaintVisitor::new();
    let mut imports = BTreeMap::new();
    for item in &parsed.module.body {
        let ModuleItem::ModuleDecl(ModuleDecl::Import(import)) = item else {
            continue;
        };
        if import.type_only || import.with.is_some() {
            continue;
        }
        let Some(url) = resolve(&parsed.url, &import.src.value.to_string_lossy()) else {
            continue;
        };
        for specifier in &import.specifiers {
            let (local, exported) = match specifier {
                ImportSpecifier::Named(named) if !named.is_type_only => (
                    named.local.sym.to_string(),
                    named
                        .imported
                        .as_ref()
                        .map_or_else(|| named.local.sym.to_string(), export_name),
                ),
                ImportSpecifier::Default(default) => {
                    (default.local.sym.to_string(), "default".to_owned())
                }
                _ => continue,
            };
            if let Some(value) = exports.get(&(url.clone(), exported)) {
                visitor.insert_var(local.clone(), value.origin.clone());
                imports.insert(local, value.clone());
            }
        }
    }
    (visitor, imports)
}

fn exported_locals(module: &Module) -> Vec<(String, String)> {
    let mut bindings = Vec::new();
    for item in &module.body {
        match item {
            ModuleItem::ModuleDecl(ModuleDecl::ExportNamed(named))
                if named.src.is_none() && !named.type_only =>
            {
                for specifier in &named.specifiers {
                    if let ExportSpecifier::Named(named) = specifier {
                        if !named.is_type_only {
                            bindings.push((
                                named
                                    .exported
                                    .as_ref()
                                    .map_or_else(|| export_name(&named.orig), export_name),
                                export_name(&named.orig),
                            ));
                        }
                    }
                }
            }
            ModuleItem::ModuleDecl(ModuleDecl::ExportDecl(export)) => {
                if let Decl::Var(var) = &export.decl {
                    for decl in &var.decls {
                        if let Some(name) = pat_ident_name(&decl.name) {
                            bindings.push((name.clone(), name));
                        }
                    }
                }
            }
            _ => {}
        }
    }
    bindings
}

fn locations(
    origin: &str,
    parsed: &ParsedModule,
    imports: &BTreeMap<String, ExportValue>,
) -> BTreeSet<String> {
    let mut locations = BTreeSet::from([parsed.url.to_string()]);
    for value in imports.values() {
        if origin == value.origin
            || origin
                .strip_prefix(&value.origin)
                .is_some_and(|tail| tail.starts_with(" -> "))
        {
            locations.extend(value.locations.iter().cloned());
        }
    }
    locations
}

fn summarize(parsed: &ParsedModule, exports: &Exports) -> BTreeMap<String, ExportValue> {
    let (mut visitor, imports) = seed_imports(parsed, exports);
    let mut default_export = None;
    for item in &parsed.module.body {
        let declaration = match item {
            ModuleItem::Stmt(Stmt::Decl(Decl::Var(var))) => Some(var),
            ModuleItem::ModuleDecl(ModuleDecl::ExportDecl(export)) => match &export.decl {
                Decl::Var(var) => Some(var),
                _ => None,
            },
            ModuleItem::ModuleDecl(ModuleDecl::ExportDefaultExpr(default)) => {
                default_export = visitor
                    .classify(&default.expr)
                    .map(|(origin, _)| ExportValue {
                        locations: locations(&origin, parsed, &imports),
                        origin,
                    });
                None
            }
            ModuleItem::Stmt(Stmt::Expr(expression)) => {
                if let Expr::Assign(assign) = &*expression.expr {
                    visitor.assign_var(assign);
                }
                None
            }
            // Export summaries deliberately require straight-line module
            // initialization. Unsupported control flow cannot leak block-local
            // bindings or hide a definite overwrite of an exported value.
            ModuleItem::Stmt(
                Stmt::Block(_)
                | Stmt::If(_)
                | Stmt::For(_)
                | Stmt::ForIn(_)
                | Stmt::ForOf(_)
                | Stmt::While(_)
                | Stmt::DoWhile(_)
                | Stmt::Switch(_)
                | Stmt::Try(_)
                | Stmt::With(_)
                | Stmt::Labeled(_),
            ) => return BTreeMap::new(),
            _ => None,
        };
        if let Some(var) = declaration {
            for decl in &var.decls {
                if let Some(name) = pat_ident_name(&decl.name) {
                    let origin = decl
                        .init
                        .as_deref()
                        .and_then(|value| visitor.classify(value))
                        .map(|(origin, _)| origin);
                    visitor.scopes[0].insert(name, origin);
                }
            }
        }
    }
    let mut result = BTreeMap::new();
    for (exported, local) in exported_locals(&parsed.module) {
        if let Some(origin) = visitor.lookup(&local) {
            result.insert(
                exported,
                ExportValue {
                    locations: locations(&origin, parsed, &imports),
                    origin,
                },
            );
        }
    }
    if let Some(value) = default_export {
        result.insert("default".to_owned(), value);
    }
    result
}

impl DomSinkExtractor {
    /// Extract additional static candidates across explicit ES-module imports.
    /// Inputs must belong to one session and retain their fetched final URLs.
    /// Files remain separate ASTs. Work is capped at 128 modules, 512 KiB per
    /// module, 8 MiB total and eight linking passes. Inputs beyond those caps
    /// remain covered by ordinary single-file extraction. No network I/O or
    /// runtime execution occurs; a candidate is never `Confirmed`.
    pub fn retain_module_input(inputs: &mut Vec<ExtractInput>, input: ExtractInput) {
        if input.kind == ContentKind::JavaScript
            && input.url.is_some()
            && (input.body.contains("import") || input.body.contains("export"))
            && input.body.len() <= MAX_MODULE_BYTES
            && inputs.len() < MAX_MODULES
            && inputs.iter().map(|item| item.body.len()).sum::<usize>() + input.body.len()
                <= MAX_TOTAL_BYTES
        {
            inputs.push(input);
        }
    }

    /// Analyze a bounded collection of fetched ES modules. See
    /// [`Self::retain_module_input`] for incremental input collection.
    #[must_use]
    pub fn extract_modules(inputs: &[ExtractInput]) -> Vec<Finding> {
        if !inputs.iter().any(|input| input.body.contains("import")) {
            return Vec::new();
        }
        let Some(session) = inputs.first().map(|input| input.session_id) else {
            return Vec::new();
        };
        let mut bytes = 0usize;
        let mut url_counts = BTreeMap::new();
        for input in inputs
            .iter()
            .take(MAX_MODULES)
            .filter(|input| input.session_id == session)
        {
            if let Some(url) = input.url.as_deref().and_then(|url| Url::parse(url).ok()) {
                *url_counts.entry(url.to_string()).or_insert(0usize) += 1;
            }
        }
        let parsed: Vec<_> = inputs
            .iter()
            .filter(|input| input.session_id == session)
            .take(MAX_MODULES)
            .filter_map(|input| {
                if bytes.saturating_add(input.body.len()) > MAX_TOTAL_BYTES {
                    return None;
                }
                let parsed = parse(input)?;
                // Conflicting versions of one URL cannot be linked safely.
                if url_counts.get(parsed.url.as_str()) != Some(&1) {
                    return None;
                }
                bytes += input.body.len();
                Some(parsed)
            })
            .collect();
        let mut exports = Exports::new();
        for _ in 0..MAX_LINK_PASSES {
            let mut next = Exports::new();
            for module in &parsed {
                for (name, value) in summarize(module, &exports) {
                    next.insert((module.url.to_string(), name), value);
                }
            }
            if exports == next {
                break;
            }
            exports = next;
        }
        let mut findings = Vec::new();
        for module in &parsed {
            let (mut visitor, imports) = seed_imports(module, &exports);
            if imports.is_empty() {
                continue;
            }
            module.module.visit_with(&mut visitor);
            let mut local = TaintVisitor::new();
            module.module.visit_with(&mut local);
            let local_traces: BTreeSet<_> =
                local.traces.into_iter().map(|(value, _)| value).collect();
            let mut seen = BTreeSet::new();
            for (value, _) in visitor.traces {
                if local_traces.contains(&value) || !seen.insert(value.clone()) {
                    continue;
                }
                let origin = value
                    .strip_prefix("DOM XSS: ")
                    .and_then(|flow| flow.rsplit_once(" -> "))
                    .map_or("", |(origin, _)| origin);
                let mut finding = Finding::new(
                    session,
                    FindingKind::Config,
                    None,
                    value.clone(),
                    Confidence::Medium,
                    Provenance::new(Source::JsAst, Some(module.url.to_string())),
                );
                finding.status = webrev_core::FindingStatus::Suspicious;
                finding.detectors.push("dom-sinks-modules".to_owned());
                "Static source-to-sink candidate linked through explicit ES-module value imports. Runtime reachability, sanitizer context and exploitability remain unverified.".clone_into(&mut finding.justification);
                finding.provenances = locations(origin, module, &imports)
                    .into_iter()
                    .map(|url| Provenance::new(Source::JsAst, Some(url)))
                    .collect();
                findings.push(finding);
            }
        }
        findings
    }
}

#[cfg(test)]
mod tests;
